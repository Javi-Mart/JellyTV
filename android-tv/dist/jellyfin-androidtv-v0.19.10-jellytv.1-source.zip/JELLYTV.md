# JellyTV 1.0.0 debug source

Based on Jellyfin Android TV v0.19.10, commit 984181a3d6ab14e9a6d2dcc850c582e1c138bd95.
Contains all upstream source and the JellyTV modifications used for the accompanying APK.
License: GNU GPL version 2 (see LICENSE). Requires JDK 21 and Android SDK 36.
Build: ./gradlew -Pjellyfin.version=0.19.10-jellytv.1 assembleDebug lintDebug testDebugUnitTest
Debug signing keys are generated locally by Android tooling and are not included.
